//Base.getScript(Gobal.Skin+"/DataServer/JS/LotteryFun.js?v=130905");
Base.getScript(Gobal.Skin+"/js/mobile/LotteryFun.js");