$(function(){		
	var demo=$(".login_ConInput").Validform({
		tiptype:2,
	});	
})
