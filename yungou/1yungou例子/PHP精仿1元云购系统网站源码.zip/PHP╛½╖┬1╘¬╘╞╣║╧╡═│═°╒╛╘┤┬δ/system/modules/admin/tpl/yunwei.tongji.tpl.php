<?php defined('G_IN_ADMIN')or exit('No permission resources.'); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="<?php echo G_GLOBAL_STYLE; ?>/global/css/global.css" type="text/css">
<link rel="stylesheet" href="<?php echo G_GLOBAL_STYLE; ?>/global/css/style.css" type="text/css">
<style>
.topk3{}
.topk3 li{ line-height:35px; border-bottom:1px solid #eee}
.topk3 li a{ margin-left:30px; color:#9CC}
</style>
</head>
<body>
<div class="header lr10">
	<?php echo $this->headerment();?>
</div>
<div class="bk10"></div>
<div class="header-data lr10">
	<b>统计入口</b> 
</div>
<div class="bk10"></div>

<div class="table-list lr10">
  <table width="100%" cellspacing="0">
  	<tbody>
    	<tr>
        	<td width="120px">百度统计入口:</td>
            <td><a target="_blank" href="http://tongji.baidu.com/">http://tongji.baidu.com/</a></td>
        </tr>
        <tr>
        	<td width="120px">量子统计入口:</td>
             <td><a target="_blank" href="http://www.linezing.com/">http://www.linezing.com/</a></td>
        </tr>
          <tr>
        	<td width="120px">站长统计入口:</td>
             <td><a target="_blank" href="http://www.cnzz.com/">http://www.cnzz.com/</a></td>
        </tr>
          <tr>
        	<td width="120px">51啦统计入口:</td>
             <td><a target="_blank" href="http://www.51.la/">http://www.51.la/</a></td>
        </tr>
	</tbody>
</table>	
</div>
</div><!--table-list end-->
<div class="btn_paixu"></div>
<div class="bk30"></div>
<script>
	
</script>
</body>
</html> 