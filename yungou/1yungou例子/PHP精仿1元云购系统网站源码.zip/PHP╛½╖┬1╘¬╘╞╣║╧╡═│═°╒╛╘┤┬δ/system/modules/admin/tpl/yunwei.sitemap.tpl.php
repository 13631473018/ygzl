<?php defined('G_IN_ADMIN')or exit('No permission resources.'); ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<link rel="stylesheet" href="<?php echo G_GLOBAL_STYLE; ?>/global/css/global.css" type="text/css">
<link rel="stylesheet" href="<?php echo G_GLOBAL_STYLE; ?>/global/css/style.css" type="text/css">
<style>
.topk3{}
.topk3 li{ line-height:35px; border-bottom:1px solid #eee}
.topk3 li a{ margin-left:30px; color:#9CC; }
</style>
</head>
<body>
<div class="header lr10">
	<?php echo $this->headerment();?>
</div>
<div class="bk10"></div>
<div class="header-data lr10">
	<b>站点地图下载器,请下载站点地图生成器,生成成功后上传至服务器根目录</b> 
</div>
<div class="bk10"></div>

<div class="table-list lr10">
	<a target="_blank" href="http://www.sitemapx.com/SiteMapX_setup.exe"><img src="http://cn.sitemapx.com/images/download-free.gif" /></a>
</div>
</div><!--table-list end-->
<div class="btn_paixu"></div>
<div class="bk30"></div>
<script>
	
</script>
</body>
</html> 