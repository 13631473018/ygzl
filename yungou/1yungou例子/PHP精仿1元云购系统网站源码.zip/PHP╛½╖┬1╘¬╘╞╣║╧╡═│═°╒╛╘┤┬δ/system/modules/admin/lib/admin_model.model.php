<?php 
System::load_sys_class('model','sys','no');
class admin_model extends model {

	public function __construct() {		
		parent::__construct();
	}
}

?>