<?php return array (
  'qq' => 
  array (
    'off' => 1,
    'id' => '213213234',
    'key' => '234234234234234',
  ),
  'weibo' => 
  array (
    'off' => '0',
  ),
); ?>