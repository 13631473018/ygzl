{

"appid":"100537294",

"appkey":"837edda8fdda0d7624efd7f6c83b99f8",

"callback":"http://www.yungoucms.cn/?/api/qqlogin/callback/",

"scope":"get_user_info",

"errorReport":true,

"storageType":"file",

"host":"localhost",


"user":"root",

"password":"root",


"database":"test"


}