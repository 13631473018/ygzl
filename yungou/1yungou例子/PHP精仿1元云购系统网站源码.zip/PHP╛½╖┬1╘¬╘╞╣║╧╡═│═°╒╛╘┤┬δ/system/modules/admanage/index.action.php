<?php 

defined('G_IN_SYSTEM')or exit('No permission resources.');
class index extends SystemAction {


	public function init(){
	
	
	}

}


?>