				<?php 
					return array (
						'mid' => '',
						'mpass' => '',
						'mqianming' => ''
					);
				?>