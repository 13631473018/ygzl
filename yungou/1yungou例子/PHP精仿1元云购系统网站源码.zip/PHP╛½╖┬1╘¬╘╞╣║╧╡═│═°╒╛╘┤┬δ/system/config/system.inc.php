<?php 
 defined('G_IN_SYSTEM') or exit('No permission resources.'); 
return array( 
'web_name' => '云购CMS ',//网站名 
'web_key' => '是一个云购系统',//网站关键字 
'web_des' => '是一个云购系统',//网站介绍 
'web_path' => 'demo.52jscn.com',//网站地址 
'templates_edit' => '1',//是否允许在线编辑模板 
'templates_name' => 'yungou',//当前模板方案 
'charset' => 'utf-8',//网站字符集 
'timezone' => 'Asia/Shanghai',//网站时区 
'error' => '0',//1、保存错误日志到 cache/error_log.php | 0、在页面直接显示 
'gzip' => '0',//是否Gzip压缩后输出,服务器没有gzip请不要启用 
'lang' => 'zh-cn',//网站语言包 
'cache' => '3600',//默认缓存时间 
'web_off' => '1',//网站是否开启 
'web_off_text' => '网站关闭。升级中....',//关闭原因 
'tablepre' => 'QCNf',// 
'index_name' => '?',//隐藏首页文件名 
'expstr' => '/',//url分隔符号 
'admindir' => 'admin',//后台管理文件夹 
'qq' => '1078119275',//qq 
'cell' => '152-2293-3000',//联系电话 
'web_logo' => 'banner/logo.png',//logo 
'web_copyright' => '爱琅戈提供本系统',//版权 
'web_name_two' => '1元云购',//短网站名 
'qq_qun' => '123456|456789',//QQ群 
'goods_end_time' => '180',//开奖动画秒数(单位秒) 
); 
 ?>