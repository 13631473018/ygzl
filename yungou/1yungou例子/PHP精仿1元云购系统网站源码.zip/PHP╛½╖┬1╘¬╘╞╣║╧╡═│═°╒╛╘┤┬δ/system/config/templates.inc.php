<?php 
 defined('G_IN_SYSTEM') or exit('No permission resources.');
 return array (
  'yungou' => 
  array (
    'name' => '云购默认模板',
    'dir' => 'yungou',
    'html' => 'html',
    'author' => '韬龙网络1',
  ),
)
 ?>