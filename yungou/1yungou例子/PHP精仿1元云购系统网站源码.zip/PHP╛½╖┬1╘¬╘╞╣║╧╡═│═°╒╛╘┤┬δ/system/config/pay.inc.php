<?php 

return array (
	"alipay" => array(
					  'mid'=>"",
					  "key"=>""
					  ),
	"tenpay" => array(
					  "mid" => "1900000109",
					  "key" => "8934e7d15453e97507ef794cf7b0519d",
					  "type" => '2',
					  ),
)
?>