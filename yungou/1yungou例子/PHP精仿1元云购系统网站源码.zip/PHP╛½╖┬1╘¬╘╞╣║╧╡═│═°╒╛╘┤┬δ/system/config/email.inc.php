			<?php 
			return array (	
				'stmp_host' => '',	//stmp服务器
				'user' => '',//账号
				'pass' => '',		//密码
				'big' => 'utf-8',				//发送编码
				'from' => "",//发件人
				'fromName' => "云购官方",  		//发件人名
				'nohtml' => "不支持HTML格式",  	//不支持HTML
				'template' => ''
			);
			?>