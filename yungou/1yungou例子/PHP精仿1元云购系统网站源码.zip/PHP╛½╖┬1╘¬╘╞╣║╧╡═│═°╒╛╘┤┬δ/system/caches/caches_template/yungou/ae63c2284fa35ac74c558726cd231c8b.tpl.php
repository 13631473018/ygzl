<?php defined('G_IN_SYSTEM')or exit('No permission resources.'); ?><?php include templates("index","header");?>
<link rel="stylesheet" type="text/css" href="<?php echo G_TEMPLATES_STYLE; ?>/css/newbie.css"/>
<div class="GuideContent clearfix">
	<div class="GuideW">
		<div class="Guidehead">
			<p><img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_1.jpg" border="0" alt=""></p>
			<p><img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_2.jpg" border="0" alt=""></p>
		</div>
		<div class="Guidebor clearfix">
			<ul class="Guide-Explain clearfix">
				<li class="Explain-l ExplainA"><p>选择一款商品，点击“立即1元云购”</p><img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_3.jpg" border="0" alt=""></li>
				<li class="Explain-r Explainimg"><img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_4.jpg" border="0" alt=""></li>
			</ul>
			<div class="Guide-Separate">
				<img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_5.jpg" border="0" alt="">
			</div>
			<ul class="Guide-Explain clearfix">
				<li class="Explain-l Explainimg"><img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_6.jpg" border="0" alt=""></li>
				<li class="Explain-r ExplainB"><p>支付1元，购买1人次，获得1个“云购码”</p><img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_7.jpg" border="0" alt=""></li>
			</ul>
			<div class="Guide-Separate">
				<img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_5.jpg" border="0" alt="">
			</div>
			<ul class="Guide-Explain clearfix">
				<li class="Explain-l ExplainC"><p>当一件商品达到总参与人次，抽出1名商品获得者；</p><img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_8.jpg" border="0" alt=""></li>
				<li class="Explain-r Explainimg"><img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_9.jpg" border="0" alt=""></li>
			</ul>
			<div class="Guide-Separate">
				<img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_5.jpg" border="0" alt="">
			</div> 
			<div class="Rule clearfix">
				<h2><img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_10.jpg" border="0" alt=""></h2>
				<ul class="Rule-Exp">
					<li>每件商品参考市场价平分成相应“等份”，每份1元，1份对应1个云购码。</li>
					<li>同一件商品可以购买多次或一次购买多份。</li>
					<li>当一件商品所有“等份”全部售出后计算出“幸运云购码”，拥有“幸运云购码”者即可获得此商品。</li>
				</ul>
			</div>
			<div class="Rule clearfix Rulemat">
				<h2><img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_11.jpg" border="0" alt=""></h2>
				<ul class="Rule-Exp">
					<li>取该商品最后购买时间前网站所有商品100条购买时间记录（限时揭晓商品取截止时间前网站所有商品100条购买时间记录）。</li>
					<li>时间按时、分、秒、毫秒依次排列组成一组数值。</li>
					<li>将这100组数值之和除以商品总需参与人次后取余数，余数加上10,000,001即为“幸运云购码”。</li>
				</ul>
			</div>
			<div class="Rule-line"></div>
			<div class="Rule-button">
				<a href="<?php echo WEB_PATH; ?>" target="_blank"><img src="<?php echo G_UPLOAD_PATH; ?>/newbie/Guide_14.jpg" border="0" alt=""></a>
			</div>
		</div>
		<div class="Rule-Anglebg">
		</div>
		<div class="clear"></div>
	</div>
</div>
<!--新手指南结束-->
<?php include templates("index","footer");?>