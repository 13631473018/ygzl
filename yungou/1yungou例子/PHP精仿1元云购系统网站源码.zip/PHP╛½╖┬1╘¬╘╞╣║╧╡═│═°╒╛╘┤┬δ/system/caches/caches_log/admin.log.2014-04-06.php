<?php exit; ?> 



2014-04-06 15:42:12------>array (
  0 => 'UPDATE `go_admin` SET `logintime`=\'1396770132\' WHERE (`uid`=\'1\')',
  1 => 'UPDATE `go_admin` SET `loginip`=\'127.0.0.1\' WHERE (`uid`=\'1\')',
) 



2014-04-06 15:49:45------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS — 搜虎精品社区www.souho.net提供程序\' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'http://test.souho.net/\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'搜虎精品社区www.souho.net提供程序\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 15:49:53------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS — 搜虎精品社区www.souho.net提供程序\' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'http://test.souho.net/\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'搜虎精品社区www.souho.net提供程序\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 16:02:51------>array (
  0 => 'UPDATE `go_admin` SET `logintime`=\'1396771371\' WHERE (`uid`=\'1\')',
  1 => 'UPDATE `go_admin` SET `loginip`=\'127.0.0.1\' WHERE (`uid`=\'1\')',
) 



2014-04-06 16:08:05------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS \' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'127.0.0.1\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'爱琅戈提供本程序\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 16:14:48------>array (
  0 => 'UPDATE `go_caches` SET `value` = \'yeepay\' where `key` = \'pay_bank_type\'',
) 



2014-04-06 17:06:27------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS \' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'127.0.0.1\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'爱琅戈提供本程序\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 17:10:49------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS \' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'127.0.0.1\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'爱琅戈提供本程序\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 17:12:17------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS \' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'127.0.0.1\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'爱琅戈提供本程序\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 19:03:58------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS \' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'127.0.0.1\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'爱琅戈提供本程序\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 19:04:30------>array (
  0 => 'UPDATE `go_admin` SET `logintime`=\'1396782270\' WHERE (`uid`=\'1\')',
  1 => 'UPDATE `go_admin` SET `loginip`=\'127.0.0.1\' WHERE (`uid`=\'1\')',
) 



2014-04-06 19:04:39------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS \' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'127.0.0.1\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'爱琅戈提供本程序\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 19:07:41------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS \' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'127.0.0.1\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'爱琅戈提供本程序\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 19:07:53------>array (
  0 => 'UPDATE `go_config` SET `value`=\'utf-8\' WHERE (`name`=\'charset\')',
  1 => 'UPDATE `go_config` SET `value`=\'Asia/Shanghai\' WHERE (`name`=\'timezone\')',
  2 => 'UPDATE `go_config` SET `value`=\'1\' WHERE (`name`=\'error\')',
  3 => 'UPDATE `go_config` SET `value`=\'0\' WHERE (`name`=\'gzip\')',
  4 => 'UPDATE `go_config` SET `value`=\'?\' WHERE (`name`=\'index_name\')',
  5 => 'UPDATE `go_config` SET `value`=\'/\' WHERE (`name`=\'expstr\')',
  6 => 'UPDATE `go_config` SET `value`=\'admin\' WHERE (`name`=\'admindir\')',
  7 => 'UPDATE `go_config` SET `value`=\'1\' WHERE (`name`=\'web_off\')',
  8 => 'UPDATE `go_config` SET `value`=\'网站关闭。升级中....\' WHERE (`name`=\'web_off_text\')',
  9 => 'UPDATE `go_config` SET `value`=\'123456\' WHERE (`name`=\'qq\')',
  10 => 'UPDATE `go_config` SET `value`=\'123456|456789\' WHERE (`name`=\'qq_qun\')',
  11 => 'UPDATE `go_config` SET `value`=\'023-68555555\' WHERE (`name`=\'cell\')',
  12 => 'UPDATE `go_config` SET `value`=\'180\' WHERE (`name`=\'goods_end_time\')',
) 



2014-04-06 19:08:36------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS \' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'127.0.0.1\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'爱琅戈提供本程序\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 19:20:25------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS \' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'127.0.0.1\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'123\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 19:20:43------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS \' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'127.0.0.1\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'爱琅戈提供本系统\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 19:24:44------>array (
  0 => 'UPDATE `go_config` SET `value`=\'云购CMS \' WHERE (`name`=\'web_name\')',
  1 => 'UPDATE `go_config` SET `value`=\'1元云购\' WHERE (`name`=\'web_name_two\')',
  2 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_key\')',
  3 => 'UPDATE `go_config` SET `value`=\'是一个云购系统\' WHERE (`name`=\'web_des\')',
  4 => 'UPDATE `go_config` SET `value`=\'127.0.0.1\' WHERE (`name`=\'web_path\')',
  5 => 'UPDATE `go_config` SET `value`=\'banner/logo.png\' WHERE (`name`=\'web_logo\')',
  6 => 'UPDATE `go_config` SET `value`=\'爱琅戈提供本系统\' WHERE (`name`=\'web_copyright\')',
) 



2014-04-06 19:33:42------>array (
  0 => 'insert into `go_qqset`(`qq`,`name`,`type`,`qqurl`,`full`,`province`,`city`,`county`,`subtime`) values(\'1111111\',\'1111\',\'直属群\',\'11111\',\'已满\',\'省份\',\'地级市\',\'市、县级市\',\'1396784022\')',
) 



2014-04-06 19:35:15------>array (
  0 => 'insert into `go_qqset`(`qq`,`name`,`type`,`qqurl`,`full`,`province`,`city`,`county`,`subtime`) values(\'6666666\',\'66666666\',\'直属群\',\'666666\',\'已满\',\'省份\',\'地级市\',\'市、县级市\',\'1396784115\')',
) 



2014-04-06 19:37:31------>array (
  0 => 'insert into `go_qqset`(`qq`,`name`,`type`,`qqurl`,`full`,`province`,`city`,`county`,`subtime`) values(\'111111111\',\'111111111111111\',\'直属群\',\'11111111\',\'已满\',\'省份\',\'地级市\',\'市、县级市\',\'1396784251\')',
) 



2014-04-06 19:38:13------>array (
  0 => 'insert into `go_qqset`(`qq`,`name`,`type`,`qqurl`,`full`,`province`,`city`,`county`,`subtime`) values(\'日日日日日\',\'日日日日\',\'直属群\',\'日日日日\',\'已满\',\'省份\',\'地级市\',\'市、县级市\',\'1396784293\')',
) 



2014-04-06 19:39:15------>array (
  0 => 'insert into `go_qqset`(`qq`,`name`,`type`,`qqurl`,`full`,`province`,`city`,`county`,`subtime`) values(\'6666666\',\'6666666\',\'直属群\',\'6666666\',\'已满\',\'省份\',\'地级市\',\'市、县级市\',\'1396784355\')',
) 



2014-04-06 19:40:29------>array (
  0 => 'insert into `go_qqset`(`qq`,`name`,`type`,`qqurl`,`full`,`province`,`city`,`county`,`subtime`) values(\'6666666\',\'6666666\',\'直属群\',\'6666666\',\'已满\',\'省份\',\'地级市\',\'市、县级市\',\'1396784429\')',
) 



2014-04-06 19:55:53------>array (
  0 => 'INSERT INTO `go_egglotter_rule`(rule_name,starttime,endtime,subtime,lotterytype,lotterjb,	ruledesc,startusing)VALUES(\'111\',\'1396713600\',\'1396713600\',\'1396785353\',\'1\',	\'11\',\'1111\',\'1\')',
  1 => 'INSERT INTO `go_egglotter_spoil`(rule_id,spoil_name,subtime,spoil_dj,spoil_jl) VALUES(\'1\',\'111\',\'1396785353\',\'1\',\'111\')',
  2 => 'INSERT INTO `go_egglotter_spoil`(rule_id,spoil_name,subtime,spoil_dj,spoil_jl) VALUES(\'1\',\'111\',\'1396785353\',\'2\',\'111\')',
  3 => 'INSERT INTO `go_egglotter_spoil`(rule_id,spoil_name,subtime,spoil_dj,spoil_jl) VALUES(\'1\',\'\',\'1396785353\',\'3\',\'111\')',
) 



2014-04-06 20:02:08------>array (
  0 => 'UPDATE `go_egglotter_rule` SET `rule_name`=\'111\',`starttime`=\'1396713600\',`endtime`=\'1397577600\',	`subtime`=\'1396785728\',`lotterytype`=\'1\',`lotterjb`=\'11\',`ruledesc`=\'1111\',`startusing`=\'1\'	where `rule_id`=\'1\'',
  1 => 'UPDATE `go_egglotter_spoil`set `spoil_name`=\'111\',`subtime`=\'1396785728\',`spoil_jl`=\'111\' where `rule_id`=\'1\' and `spoil_dj`=\'1\'',
  2 => 'UPDATE `go_egglotter_spoil`set `spoil_name`=\'111\',`subtime`=\'1396785728\',`spoil_jl`=\'111\' where `rule_id`=\'1\' and `spoil_dj`=\'2\'',
  3 => 'UPDATE `go_egglotter_spoil`set `spoil_name`=\'\',`subtime`=\'1396785728\',`spoil_jl`=\'111\' where `rule_id`=\'1\' and `spoil_dj`=\'3\'',
) 



2014-04-06 20:03:05------>array (
  0 => 'UPDATE `go_fund` SET `fund_off` = \'0\',`fund_money` = \'77777\',`fund_count_money` = \'687676\'',
) 



2014-04-06 20:06:14------>array (
  0 => 'UPDATE `go_fund` SET `fund_off` = \'1\',`fund_money` = \'77777\',`fund_count_money` = \'687676.00\'',
) 



2014-04-06 20:06:26------>array (
  0 => 'UPDATE `go_fund` SET `fund_off` = \'1\',`fund_money` = \'77777\',`fund_count_money` = \'687676\'',
) 



2014-04-06 20:25:46------>array (
  0 => 'UPDATE `go_admin` SET `logintime`=\'1396787146\' WHERE (`uid`=\'1\')',
  1 => 'UPDATE `go_admin` SET `loginip`=\'127.0.0.1\' WHERE (`uid`=\'1\')',
) 



2014-04-06 20:32:26------>array (
  0 => 'UPDATE `go_admin` SET `logintime`=\'1396787546\' WHERE (`uid`=\'1\')',
  1 => 'UPDATE `go_admin` SET `loginip`=\'127.0.0.1\' WHERE (`uid`=\'1\')',
) 



2014-04-06 20:35:54------>array (
  0 => 'UPDATE `go_fund` SET `fund_off` = \'1\',`fund_money` = \'77777\',`fund_count_money` = \'888888\'',
) 



2014-04-06 20:37:19------>array (
  0 => 'UPDATE `go_fund` SET `fund_off` = \'1\',`fund_money` = \'0.5\',`fund_count_money` = \'888888.00\'',
) 



2014-04-06 22:02:18------>array (
  0 => 'INSERT INTO `go_member` (username,img,email,mobile,password,money,jingyan,score,emailcode,mobilecode,qianming,groupid,time) value (\'123456www\',\'photo/member.jpg\',\'123456www@qq.com\',\'12345612345\',\'282bdde8be377a9014e509adca56d2b0\',\'555555\',\'555555\',\'555555\',\'1\',\'1\',\'\',\'1\',\'1396792938\')',
) 



2014-04-06 22:03:38------>array (
  0 => 'UPDATE `go_member` SET `username`=\'123456www\',`email`=\'123456www@qq.com\',`mobile`=\'13555555555\',`password`=\'4838cba43ce3fdb5457cf5228cd154d4\',`money`=\'555555.00\',`jingyan`=\'555555\',`score`=\'555555\',`emailcode`=\'1\',`mobilecode`=\'1\',`img`=\'photo/member.jpg\',`groupid`=\'1\',`qianming`=\'\' WHERE `uid`=\'13551\'',
) 



2014-04-06 22:06:05------>array (
  0 => 'INSERT INTO `go_shoplist` (`cateid`, `brandid`, `title`, `title_style`, `title2`, `keywords`, `description`, `money`, `yunjiage`, `zongrenshu`, `canyurenshu`,`shenyurenshu`, `qishu`,`maxqishu`,`thumb`, `picarr`, `content`,`xsjx_time`,`renqi`,`pos`, `time`) VALUES (\'6\', \'11\', \'1111111\', \'\', \'\', \'\', \'\', \'111\', \'1\', \'111\', \'0\',\'111\', \'1\',\'100\', \'photo/goods.jpg\', \'a:0:{}\', \'\',\'0\',\'0\', \'0\',\'1396793164\')',
  1 => 'INSERT INTO `go_shopcodes_1` (`s_id`, `s_cid`, `s_len`, `s_codes`,`s_codes_tmp`) VALUES (\'16896\', \'1\',\'111\',\'a:111:{i:0;i:10000053;i:1;i:10000030;i:2;i:10000052;i:3;i:10000006;i:4;i:10000027;i:5;i:10000102;i:6;i:10000078;i:7;i:10000098;i:8;i:10000049;i:9;i:10000025;i:10;i:10000110;i:11;i:10000041;i:12;i:10000092;i:13;i:10000014;i:14;i:10000028;i:15;i:10000070;i:16;i:10000107;i:17;i:10000084;i:18;i:10000022;i:19;i:10000071;i:20;i:10000016;i:21;i:10000058;i:22;i:10000075;i:23;i:10000036;i:24;i:10000056;i:25;i:10000009;i:26;i:10000096;i:27;i:10000109;i:28;i:10000076;i:29;i:10000044;i:30;i:10000057;i:31;i:10000072;i:32;i:10000033;i:33;i:10000029;i:34;i:10000031;i:35;i:10000103;i:36;i:10000090;i:37;i:10000040;i:38;i:10000024;i:39;i:10000018;i:40;i:10000094;i:41;i:10000004;i:42;i:10000105;i:43;i:10000106;i:44;i:10000015;i:45;i:10000091;i:46;i:10000082;i:47;i:10000088;i:48;i:10000083;i:49;i:10000093;i:50;i:10000095;i:51;i:10000039;i:52;i:10000065;i:53;i:10000020;i:54;i:10000037;i:55;i:10000097;i:56;i:10000017;i:57;i:10000089;i:58;i:10000023;i:59;i:10000079;i:60;i:10000108;i:61;i:10000077;i:62;i:10000013;i:63;i:10000042;i:64;i:10000011;i:65;i:10000003;i:66;i:10000043;i:67;i:10000080;i:68;i:10000001;i:69;i:10000060;i:70;i:10000051;i:71;i:10000010;i:72;i:10000099;i:73;i:10000067;i:74;i:10000074;i:75;i:10000032;i:76;i:10000034;i:77;i:10000045;i:78;i:10000038;i:79;i:10000086;i:80;i:10000007;i:81;i:10000100;i:82;i:10000059;i:83;i:10000068;i:84;i:10000047;i:85;i:10000101;i:86;i:10000064;i:87;i:10000066;i:88;i:10000055;i:89;i:10000085;i:90;i:10000005;i:91;i:10000050;i:92;i:10000054;i:93;i:10000019;i:94;i:10000069;i:95;i:10000035;i:96;i:10000111;i:97;i:10000061;i:98;i:10000026;i:99;i:10000087;i:100;i:10000081;i:101;i:10000062;i:102;i:10000073;i:103;i:10000021;i:104;i:10000012;i:105;i:10000008;i:106;i:10000063;i:107;i:10000002;i:108;i:10000048;i:109;i:10000046;i:110;i:10000104;}\',\'a:111:{i:0;i:10000053;i:1;i:10000030;i:2;i:10000052;i:3;i:10000006;i:4;i:10000027;i:5;i:10000102;i:6;i:10000078;i:7;i:10000098;i:8;i:10000049;i:9;i:10000025;i:10;i:10000110;i:11;i:10000041;i:12;i:10000092;i:13;i:10000014;i:14;i:10000028;i:15;i:10000070;i:16;i:10000107;i:17;i:10000084;i:18;i:10000022;i:19;i:10000071;i:20;i:10000016;i:21;i:10000058;i:22;i:10000075;i:23;i:10000036;i:24;i:10000056;i:25;i:10000009;i:26;i:10000096;i:27;i:10000109;i:28;i:10000076;i:29;i:10000044;i:30;i:10000057;i:31;i:10000072;i:32;i:10000033;i:33;i:10000029;i:34;i:10000031;i:35;i:10000103;i:36;i:10000090;i:37;i:10000040;i:38;i:10000024;i:39;i:10000018;i:40;i:10000094;i:41;i:10000004;i:42;i:10000105;i:43;i:10000106;i:44;i:10000015;i:45;i:10000091;i:46;i:10000082;i:47;i:10000088;i:48;i:10000083;i:49;i:10000093;i:50;i:10000095;i:51;i:10000039;i:52;i:10000065;i:53;i:10000020;i:54;i:10000037;i:55;i:10000097;i:56;i:10000017;i:57;i:10000089;i:58;i:10000023;i:59;i:10000079;i:60;i:10000108;i:61;i:10000077;i:62;i:10000013;i:63;i:10000042;i:64;i:10000011;i:65;i:10000003;i:66;i:10000043;i:67;i:10000080;i:68;i:10000001;i:69;i:10000060;i:70;i:10000051;i:71;i:10000010;i:72;i:10000099;i:73;i:10000067;i:74;i:10000074;i:75;i:10000032;i:76;i:10000034;i:77;i:10000045;i:78;i:10000038;i:79;i:10000086;i:80;i:10000007;i:81;i:10000100;i:82;i:10000059;i:83;i:10000068;i:84;i:10000047;i:85;i:10000101;i:86;i:10000064;i:87;i:10000066;i:88;i:10000055;i:89;i:10000085;i:90;i:10000005;i:91;i:10000050;i:92;i:10000054;i:93;i:10000019;i:94;i:10000069;i:95;i:10000035;i:96;i:10000111;i:97;i:10000061;i:98;i:10000026;i:99;i:10000087;i:100;i:10000081;i:101;i:10000062;i:102;i:10000073;i:103;i:10000021;i:104;i:10000012;i:105;i:10000008;i:106;i:10000063;i:107;i:10000002;i:108;i:10000048;i:109;i:10000046;i:110;i:10000104;}\')',
  2 => 'UPDATE `go_shoplist` SET `codes_table` = \'shopcodes_1\',`sid` = \'16896\',`def_renshu` = \'0\' where `id` = \'16896\'',
) 



2014-04-06 22:15:01------>array (
  0 => 'insert into `go_member_del` select * from `go_member` where uid=\'13551\'',
  1 => 'delete from `go_member` where uid=\'13551\'',
) 



